
#ifndef GPIO_H
#define	GPIO_H


void gpio_setup();

#endif	/* GPIO_H */

