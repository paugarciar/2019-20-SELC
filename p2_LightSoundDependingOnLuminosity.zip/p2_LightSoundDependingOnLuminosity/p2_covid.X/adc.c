#include "pinguino.h"


volatile unsigned int valor;
volatile unsigned int marcador;


int
get_valor() {
  return valor;
}

int
get_marcador() {
    return marcador;
}

void
reset_marcador() {
    marcador=0;}


void __ISR(_ADC_VECTOR, IPL3AUTO) adc_isr (void){
    valor=get_adc();
    marcador=1;
    //IFS0CLR = _IFS0_AD1IF_MASK;
}

//Puntos del 1 al 5
/*int
adc_setup(unsigned int channel) {
  AD1CHSbits.CH0SA = channel;
  AD1CON1 = 0x0024;       // ASAM:1, SSRC: INT0
  AD1CON2 = 0;            // Un dato, entre VCC y GND, del canal A
  AD1CON3 = 0x0002;       // ADCS:2, TAD:2*(ADCS+1)*TPB=150ns
  AD1CON1SET = 0x8000;   // ADC:ON

  IFS0CLR = _IFS0_AD1IF_MASK;
  IEC0CLR = _IEC0_AD1IE_MASK;
}*/

int
adc_setup(unsigned int channel) {
  AD1CHSbits.CH0SA = channel;
  
  //Punto 8
  AD1CON1 = 0x00E4;       // ASAM:1, SSRC: INT0
  AD1CON2 = 0x0000;            // Un dato, entre VCC y GND, del canal A
  AD1CON3 = 0x1CF9;       // ADCS:2, TAD:2*(ADCS+1)*TPB=150ns
  AD1CON1SET = 0x8000;   // ADC:ON
  
  //Punto 6 y 7
  IPC5bits.AD1IP=3;
    
  IFS0CLR = _IFS0_AD1IF_MASK;
  IEC0SET = _IEC0_AD1IE_MASK;
}

int
get_adc() {
    //int val = ADC1BUF0;
    
    int val;  int i;	 
    volatile unsigned int *adc_ptr;

    val	=0;	adc_ptr	=	&ADC1BUF0; //	Primer	campo	del	buffer/array
    for	(i=0;i<4;i++,adc_ptr+=4){		//	Avanzo	de	4	en	4									
    val	+=	*adc_ptr;			//	Acumulo	para	hacer	la	media																	
    }					
    val	=val>>2;		//	Divido	entre	2																						
    				
    IFS0CLR	=	_IFS0_AD1IF_MASK;					
    //Use	val			
    return val;
}

