

#ifndef ADC_H
#define	ADC_H


int adc_setup(unsigned int channel);
int get_adc();
int get_valor();
int get_marcador();
void reset_marcador();
#endif	/* ADC_H */

