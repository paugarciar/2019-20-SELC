
#ifndef OC_H
#define	OC_H

typedef struct {
    volatile unsigned reg;
    volatile unsigned clr;
    volatile unsigned set;
    volatile unsigned inv;
} SFR;

typedef struct {
    SFR TxCON;
    SFR TMRx;
    SFR PRx;
} TMR_SFR;

#define T2_SFR    ((TMR_SFR*)(&T2CON))
#define T3_SFR    ((TMR_SFR*)(&T3CON))
#define TMR_B_VALID_PS 0xBF
#define TMR_A_VALID_PS 0xA9

typedef struct {
    SFR OCxCON;
    SFR OCxR;
    SFR OCxRS;
} OC_SFR;



#define OC_BLUE        ((OC_SFR*)(&OC3CON))
#define OC_GREEN       ((OC_SFR*)(&OC4CON))
#define OC_RED         ((OC_SFR*)(&OC1CON))
#define OC_BUZZER      ((OC_SFR*)(&OC5CON))



#define LED_BLUE_MINADC_VAL  204
#define LED_BLUE_MAXADC_VAL  460
#define LED_BLUE_RANGE       (LED_BLUE_MAXADC_VAL-LED_BLUE_MINADC_VAL)

#define LED_GREEN_MINADC_VAL  234
#define LED_GREEN_MAXADC_VAL  746
#define LED_GREEN_RANGE       (LED_GREEN_MAXADC_VAL-LED_GREEN_MINADC_VAL)

#define LED_RED_MINADC_VAL  560
#define LED_RED_MAXADC_VAL  816
#define LED_RED_RANGE       (LED_RED_MAXADC_VAL-LED_RED_MINADC_VAL)


#ifdef __MPLAB_DEBUGGER_SIMULATOR 
#define T3_PS               1
#define BUZZER_MAX_FREQ     880*100
#define BUZZER_MIN_FREQ     220*100
#else
#define T3_PS               4
#define BUZZER_MAX_FREQ     880
#define BUZZER_MIN_FREQ     220
#endif
#define BUZZER_MIN_PR       (40000000/(BUZZER_MAX_FREQ*T3_PS))
#define BUZZER_MAX_PR       (40000000/(BUZZER_MIN_FREQ*T3_PS))
#define BUZZER_RANGE_PR     (BUZZER_MAX_PR-BUZZER_MIN_PR)



int oc_setup(OC_SFR* oc, unsigned char octsel_mask);
int oc_set_duty(OC_SFR* oc, TMR_SFR* t, unsigned int duty);
int oc_set_pulse(OC_SFR* oc, TMR_SFR* t, unsigned int pulse);
int buzzer_get_pr(int adc_val);
//unsigned int buzzer_get_pr(unsigned int val);
unsigned int led_blue_get_duty(unsigned int val);
unsigned int led_green_get_duty(unsigned int val);
unsigned int led_red_get_duty(unsigned int val);

#endif	/* OC_H */

