#include "oc.h"
#include "pinguino.h"

volatile unsigned int tick;

int
get_tick() {
    return tick;
}

void
timer_reset(TMR_SFR* t) {
    t->TxCON.clr = _T2CON_ON_MASK;
    t->TMRx.reg = 0;
}

int
timer_setup(TMR_SFR* t, unsigned int pr_ps, unsigned int valid_ps) {
    unsigned int tckps = 0;
    unsigned int ps = 1;
#ifdef __MPLAB_DEBUGGER_SIMULATOR 
    unsigned int pr = pr_ps/100;
#else
    unsigned int pr = pr_ps;
#endif
    
    while (pr > (1 << 16)) {
        valid_ps &= (~ps);
        if (!valid_ps) {
            return -1;
        }
        
        for(pr>>=1, ps<<=1; !(ps&valid_ps); pr >>= 1, ps <<=1);

        tckps++;
    }
    
    if (pr == 0) {
        return -2;
    }
    
    t->TMRx.reg = 0;
    t->PRx.reg = pr-1;
    t->TxCON.reg = (tckps << _T2CON_TCKPS_POSITION) | _T2CON_ON_MASK;
    
    return 0;
}

void
__ISR(_TIMER_2_VECTOR, IPL2AUTO) t2_isr (void) {
    IFS0CLR = _IFS0_T2IF_MASK;
    tick++;
}
