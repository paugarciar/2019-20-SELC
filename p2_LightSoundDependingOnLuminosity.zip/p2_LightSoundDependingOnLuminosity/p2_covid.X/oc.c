#include "oc.h"
#include "timer.h"
#include "pinguino.h"

int
oc_setup(OC_SFR* oc, unsigned char octsel_mask) {
    oc->OCxR.reg = 0;
    oc->OCxRS.reg = 0;
    oc->OCxCON.reg = 0x8006 | octsel_mask;
}

int
oc_set_duty(OC_SFR* oc, TMR_SFR* t, unsigned int duty) {
    oc->OCxRS.reg = (duty * t->PRx.reg) / 100;
}

int
oc_set_pulse(OC_SFR* oc, TMR_SFR* t, unsigned int pulse) {
    unsigned int tckps = (t->TxCON.reg & _T2CON_TCKPS_MASK) >> _T2CON_TCKPS_POSITION;
    if (tckps == 7) {
        tckps = 8;
    }
    oc->OCxRS.reg = pulse >> tckps;
}
int
buzzer_get_pr(int adc_val){
    int pr_val;
    pr_val=455 + 1.3311*adc_val;
    return pr_val;
}
/*unsigned int buzzer_get_pr(unsigned int val){
    if (val<=0){//ADC da valores entre 0 y 1024
        return BUZZER_MIN_PR;}
    if (val>=1024){
        return BUZZER_MAX_PR;}
    {
        return (BUZZER_RANGE_PR*val)/1024+BUZZER_MIN_PR;}
    }*/ 
//Comento esta f�rmula porque la de arriba es m�s eficaz, emplea menos c�digo aunque esta use las m�scaras



unsigned int
led_blue_get_duty(unsigned int val) {
    if (val <= LED_BLUE_MINADC_VAL) {
    return 100;
}
    if (val >= LED_BLUE_MAXADC_VAL){
        return 0;
    }
    
    else {
        val = LED_BLUE_MAXADC_VAL - val;
    }
    return 100 * val / (LED_BLUE_RANGE);
}
unsigned int
led_green_get_duty(unsigned int val) {
    if (val <= LED_GREEN_MINADC_VAL) {
        return 0;
    }
    if (val >= LED_GREEN_MAXADC_VAL) {
        return 0;
    }
    val = val - LED_GREEN_MINADC_VAL;
    if (val > LED_GREEN_RANGE/2) {
        val = LED_GREEN_RANGE - val;
    }
    return 100 * val / (LED_GREEN_RANGE/2);
}

unsigned int
led_red_get_duty(unsigned int val) {
    if (val <= LED_RED_MINADC_VAL){
        return 0;
    }
    if (val >= LED_RED_MAXADC_VAL){
        return 100;
    }
    else {
        val = val - LED_RED_MINADC_VAL;
    }
    return 100 * val / (LED_RED_RANGE);
}
