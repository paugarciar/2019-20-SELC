

#ifndef TIMER_H
#define	TIMER_H

#define CALC_PR_PS2 200000
#define CALC_PR_PS3 181800

int get_tick();
void timer_reset(TMR_SFR* t);
int timer_setup(TMR_SFR* t, unsigned int pr_ps, unsigned int valid_ps);



#endif	/* TIMER_H */

