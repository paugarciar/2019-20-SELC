
#ifndef PINGUINO_H
#define	PINGUINO_H

#include <xc.h>

#include <sys/attribs.h>



#define WAIT() asm volatile("wait")
#define GIE() asm volatile("ei")
#define GID() asm volatile("di")

#define BIT(a) (1 << a)
#define BUTTON_MASK    BIT(7)
#define LDR_MASK       BIT(1)
#define LED_1_MASK     BIT(15)
#define LED_2_MASK     BIT(10)
#define LED_GREEN_MASK BIT(3)
#define LED_RED_MASK   BIT(4)
#define LED_BLUE_MASK  BIT(5) 
#define BUZZER_MASK  BIT(13)


#ifdef __MPLAB_DEBUGGER_SIMULATOR 
#define DBGprintf(a) printf a
#else
#define DBGprintf(a)
#endif


#endif	/* PINGUINO_H */

