#include "pinguino.h"

void
gpio_setup() {
    TRISBSET = BUTTON_MASK;
    ANSELCSET = LDR_MASK;
    
    //ANSELACLR = LED_2_MASK;
    TRISACLR  = LED_2_MASK;
    PORTACLR  = LED_2_MASK;

    ANSELCCLR = LED_GREEN_MASK;
    TRISCCLR  = LED_GREEN_MASK;
    PORTCCLR  = LED_GREEN_MASK;
    
    ANSELCCLR = LED_BLUE_MASK;
    TRISCCLR  = LED_BLUE_MASK;
    PORTCCLR  = LED_BLUE_MASK;
    
    ANSELCCLR = LED_RED_MASK;
    TRISCCLR  = LED_RED_MASK;
    PORTCCLR  = LED_RED_MASK;
    
    
    TRISBCLR =BUZZER_MASK;
    ANSELBCLR =BUZZER_MASK;
    
    //PPS outputs
    RPC3R = 5;  //RC3 => OC4
    RPC4R = 5;  //RC4 => OC3
    RPC5R = 5;  //RC5 => OC1
    RPB13R =6;  //RB13=> OC5
    
    INTCONbits.INT0EP = 0;
    IFS0bits.INT0IF = 0;
    IEC0bits.INT0IE = 0;
    //IPC0bits.INT0IP = 1;
}