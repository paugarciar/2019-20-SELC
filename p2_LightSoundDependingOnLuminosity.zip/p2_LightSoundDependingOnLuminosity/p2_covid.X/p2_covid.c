#include <xc.h>
#include <sys/attribs.h>
#include <stdio.h>

#include "adc.h"
#include "oc.h"
#include "gpio.h"
#include "pinguino.h"
#include "timer.h"

#pragma config FNOSC = PRIPLL           // Oscillator Selection Bits (PRImary oscillator with PLL)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable (WDT Disabled (SWDTEN Bit Controls))
#pragma config WDTPS = PS1              // Watchdog Timer Postscaler (1:1)
#pragma config FPBDIV = DIV_1           // Peripheral Clock Divisor (Pb_Clk is Sys_Clk/1)




int main() {
  unsigned int val;
  unsigned int duty_green;
  unsigned int duty_blue;
  unsigned int duty_red;
  unsigned int pr3;
  unsigned int timeout;

  if (timer_setup(T2_SFR, CALC_PR_PS2, TMR_B_VALID_PS) < 0) {
      return 1;
  }
  if (timer_setup (T3_SFR, CALC_PR_PS3, TMR_B_VALID_PS) < 0) {
      return 1;
  }
  IFS0bits.T2IF = 0;
  IEC0bits.T2IE = 1;
  IPC2bits.T2IP = 2;
  
  gpio_setup();
  
  oc_setup(OC_GREEN, 0); //_OC1CON_OCTSEL_MASK for T3
  oc_setup(OC_BLUE, 0);
  oc_setup(OC_RED, 0);
  oc_setup (OC_BUZZER,_OC1CON_OCTSEL_MASK); //_OC1CON_OCTSEL_MASK for T3
  adc_setup(7);
  
  INTCONbits.MVEC = 1;
  GIE();
  
  while (1) {
    //if (IFS0bits.AD1IF) {
      if(get_marcador()){
      //val = get_adc();
          val = get_valor();
          reset_marcador();
      //Use val
      duty_green = led_green_get_duty(val);
      oc_set_duty(OC_GREEN, T2_SFR, duty_green);
      DBGprintf(("%d,%dmV, LG:%d%%\n", val, (val*3300)/1024, duty_green));
      duty_blue = led_blue_get_duty(val);
      oc_set_duty(OC_BLUE, T2_SFR, duty_blue);
      DBGprintf(("%d,%dmV, LB:%d%%\n", val, (val*3300)/1024, duty_blue));
      duty_red = led_red_get_duty(val);
      oc_set_duty(OC_RED, T2_SFR, duty_red);
      DBGprintf(("%d,%dmV, LR:%d%%\n", val, (val*3300)/1024, duty_red));
      
      pr3 = buzzer_get_pr(val);
      OC_BUZZER -> OCxRS.reg = pr3 >> 1;
      IFS0CLR = _IFS0_T3IF_MASK; 
      while(!IFS0bits.T3IF);
      PR3 = pr3;
      //oc_set_duty (OC_BUZZER, T3_SFR, 50);
      DBGprintf(("%d, %dmV, PR: %d%%\n", val, (val*3300)/1024, pr3));
    }
     if(timeout){
         if (get_tick()>=timeout){
             IFS0bits.INT0IF = 0;
             timeout = 0;
         }
     } 
     else{
         if(IFS0bits.INT0IF){
             PORTAINV = LED_2_MASK;
             timeout = get_tick() + 40;
         }
            
     }
  }
  
  return 1;
}
      /*if(timeout==0){if(IFS0bits.INT0IF){  
        timeout= get_tick()+40; 
        PORTAINV = LED_2_MASK; 
        DBGprintf(("\n\n%d,%dmV, LG:%d%%\n", val, (val*3300)/1024, duty_green));
        DBGprintf(("%d,%dmV, LB:%d%%\n", val, (val*3300)/1024, duty_blue));
        DBGprintf(("%d,%dmV, LR:%d%%\n", val, (val*3300)/1024, duty_red));
        DBGprintf(("%d,%dmV, BUZZER:%d%%\n", val, (val*3300)/1024, pr3));

    }
            
    }
      else if(get_tick()>=timeout){ // si el tick iguala el timeout actual (se acaba el rebote) entra
    timeout= 0;              //se pone a 0 para que pueda entrar en el if de arriba y poder estar pendiente del INT0
     IFS0bits.INT0IF =0;     //pongo el flag del INT0 a 0 , asi que ahora si puede estar pendiente de si se activa, antes de entrar aqui (el perido de rebote) estaba activado asi que el programa no tiene como saber si nosotros pulsamos el boton, para el estuvo todo el tiempo activado 
     } 
    }*/
