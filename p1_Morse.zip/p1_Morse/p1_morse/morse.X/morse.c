#include "timer.h"
#include "pinguino.h"

#include <string.h>

#define TIME_BASE 1
#define TIME_DOT  TIME_BASE
#define TIME_DASH 3*TIME_DOT
#define TIME_WORD 7*TIME_DOT

const char*
morse (char c)
{
    static const char* morse_ch[] = {
        ".- ",     /* A */
        "-... ", /* B */
        "-.-. ", /* C */
        "-.. ",   /* D */
        ". ",       /* E */
        "..-. ", /* F */
        "--. ",   /* G */
        ".... ", /* H */
        ".. ",     /* I */
        ".--- ", /* J */
        "-.- ",   /* K */
        ".-.. ", /* L */
        "-- ",     /* M */
        "-. ",     /* N */
        "--- ",   /* O */
        ".--. ", /* P */
        "--.- ", /* Q */
        ".-. ",   /* R */
        "... ",   /* S */
        "- ",       /* T */
        "..- ",   /* U */
        "...- ", /* V */
        ".-- ",   /* W */
        "-..- ", /* X */
        "-.-- ", /* Y */
        "--.. ", /* Z */
    };
    if (c == ' ')
        return "  ";
    if ((c >= 'A') && (c <= 'Z'))
        c += 'a' - 'A';
    if ((c < 'a') || (c > 'z'))
        return "";
    return morse_ch[c - 'a'];
}

void
send_symbol(char val)
{
    int duration = 0;
    
    switch (val) {
              
        case '-'://tres puntos
            LEDR_ON(); 
            duration=TIME_DASH;
            //Fase 2: rellena aqu�
            break;
            
        case '.'://encender el led una vez
            LEDR_ON();
            duration=TIME_DOT;//Fase 2: rellena aqu�
            break;
            
        case ' '://apagar el led una vez
            LEDR_OFF();
            duration=TIME_BASE;//Fase 2: rellena aqu�
            break;
            
        default:    //tres espacios
            LEDR_OFF();  
            duration=TIME_WORD-2;
            //Fase 2: rellena aqu�
            break;
    }
    
    timer_delay(duration);
    LEDR_OFF();
    timer_delay(TIME_BASE);
}

void
send_morse_str(const char* str)
{
    //Fase 3: rellena aqu�. Bucle que recorre la string llamando a send_symbol
    int i;
    for (i=0 ;*str;i++,str++) {
        send_symbol(*str);

    }
}

void
send_str(const char* str)
{
    
    
    //Fase 4: rellena aqu�.
    int i;
    for (i=0 ;*str;i++,str++) {
        send_morse_str(morse(*str));
        
    }
}
