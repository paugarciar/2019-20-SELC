/* 
 * File:   timer.h
 * Author: malagon
 *
 * Created on March 28, 2019, 3:24 AM
 */

#ifndef TIMER_H
#define	TIMER_H


void timer_delay();
void timer_setup();

#endif	/* TIMER_H */

