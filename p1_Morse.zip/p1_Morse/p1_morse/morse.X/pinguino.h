/* 
 * File:   pinguino.h
 * Author: malagon
 *
 * Created on March 28, 2019, 3:23 AM
 */

#ifndef PINGUINO_H
#define	PINGUINO_H

#include <xc.h>

#define LEDR_MASK       0x0020
#define LEDR_PORT(a)    PORTC##a
#define LEDR_TRIS(a)    TRISC##a
#define LEDR_ANSEL(a)   ANSELC##a

#define LEDR_ON()   LEDR_PORT(SET)=LEDR_MASK
#define LEDR_OFF()  LEDR_PORT(CLR)=LEDR_MASK
#define LEDR_INV()  LEDR_PORT(INV)=LEDR_MASK

#define LED2_MASK       0x0400
#define LED2_PORT(a)    PORTA##a
#define LED2_TRIS(a)    TRISA##a
#define LED2_ANSEL(a)   ANSELA##a

#define LED2_ON()   LED2_PORT(SET)=LED2_MASK
#define LED2_OFF()  LED2_PORT(CLR)=LED2_MASK
#define LED2_INV()  LED2_PORT(INV)=LED2_MASK

#ifdef __MPLAB_DEBUGGER_SIMULATOR 
#define DBGprintf(a) printf a 
#else
#define DBGprintf(a)
#endif

#endif	/* PINGUINO_H */

