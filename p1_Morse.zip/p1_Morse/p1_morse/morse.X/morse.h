/* 
 * File:   morse.h
 * Author: malagon
 *
 * Created on March 28, 2019, 3:25 AM
 */

#ifndef MORSE_H
#define	MORSE_H

void send_symbol();
void send_morse_str();
void send_str();

#endif	/* MORSE_H */

