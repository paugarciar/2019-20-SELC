#include <xc.h>

#define CALC_PR 31249       //Fase 1, calculate
#define PS2_NUM 111       //Fase 1, calculate

#ifdef __MPLAB_DEBUGGER_SIMULATOR 
#define PR2_VAL ((CALC_PR+1)/1000-1)
#else
#define PR2_VAL CALC_PR
#endif

void
timer_setup() {
    //Configure Timer2 for 200ms count with 40 MHz clock for the board
    //In simulation it will be aproximately 200us. Use the same PS
    //Use the same PS value. In simulat
    T2CON = 0;      
    T2CONbits.TCKPS = PS2_NUM;
    TMR2 = 0;
    PR2 = PR2_VAL;
}

void
timer_delay(int rounds) {
    if (rounds > 0) {
        TMR2 = 0;
        T2CONbits.ON = 1;
        while (rounds--) {
            IFS0bits.T2IF = 0;
            while (IFS0bits.T2IF == 0);
        }
        T2CONbits.ON = 0;
    }
}