#include <xc.h>
#include <sys/attribs.h>

#include "pinguino.h"
#include "morse.h"
#include "timer.h"

void
led_setup() {
    LEDR_ANSEL(CLR) = LEDR_MASK;
    LEDR_TRIS(CLR) = LEDR_MASK;
    LEDR_PORT(CLR) = LEDR_MASK;

    LED2_ANSEL(CLR) = LED2_MASK;
    LED2_TRIS(CLR) = LED2_MASK;
    LED2_PORT(CLR) = LED2_MASK;
}

int
main() {
    char morse_str[] = "... --- ...   ";
    char str[] = "HOLA ";

    timer_setup();
    led_setup();
    
    DBGprintf(("Hola"));
    
    while (1) {
        //Fase 1
        IFS0bits.INT0IF = 0;
        while (!IFS0bits.INT0IF) {
            LEDR_INV();
            LED2_INV();
            timer_delay(1);
        }
        LEDR_OFF();
        LED2_OFF();

        //Fase 2
        IFS0bits.INT0IF = 0;
        while (!IFS0bits.INT0IF) {
            send_symbol('.');
            send_symbol('-');
            send_symbol(' ');
            send_symbol('-');
            timer_delay(10);
        }

        //Fase 3
        IFS0bits.INT0IF = 0;
        while (!IFS0bits.INT0IF) {
            send_morse_str(morse_str);
        }
        
        //Fase 4
        IFS0bits.INT0IF = 0;
        while (!IFS0bits.INT0IF) {
            send_str(str);
        }
    }
    return 0;
}


