#include <xc.h>
#include <sys/attribs.h>

#include "config.h"
#include "data.h"

void
adc_setup () {
#ifndef ADC_STORED  
    ANSELBSET = 0x0001;
    
    AD1CON1 = 0x8444;
    AD1CON2 = 0;
    
    AD1CON3 = 0x8000;
    AD1CHSbits.CH0SA = 2;
    AD1CSSL = 0;
    
    IPC5bits.AD1IP = 6;
    IPC5bits.AD1IS = 0;
    
    IFS0bits.AD1IF = 0;
    IEC0bits.AD1IE = 1;
#endif
}

void __ISR(_ADC_VECTOR, IPL6AUTO) _adc_ISR (void) {
    data_save(ADC1BUF0);
    IFS0bits.AD1IF = 0;
}

