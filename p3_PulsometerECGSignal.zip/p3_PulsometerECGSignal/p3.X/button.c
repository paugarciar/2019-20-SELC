#include <xc.h>
#include <sys/attribs.h>

#include "adc.h"
#include "timer.h"

volatile int pressed;
void
button_setup() {
    TRISBbits.TRISB7 = 1;
    
    pressed = 0;
    
    INTCONbits.INT0EP = 1;
    
    IFS0bits.INT0IF = 0;
    IEC0bits.INT0IE = 0;
    IPC0bits.INT0IP = 1;
    IPC0bits.INT0IS = 0;
}

int button_pressed() {
    if (pressed) {
        pressed = 0;
        return 1;
    }
    return 0;
}

void __ISR(_EXTERNAL_0_VECTOR, IPL1AUTO) button_ISR (void) {
    IFS0bits.INT0IF = 0;
    pressed = 1;
}
