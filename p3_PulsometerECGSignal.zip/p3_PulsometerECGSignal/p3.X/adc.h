/* 
 * File:   adc.h
 * Author: malagon
 *
 * Created on May 11, 2017, 4:18 PM
 */

#ifndef ADC_H
#define	ADC_H

#include "config.h"

#ifdef	__cplusplus
extern "C" {
#endif

void adc_setup ();

#ifdef ADC_STORED
#define ADC_CONVERT()
#define ADC_START()
#define ADC_STOP()
#else
#define ADC_CONVERT() AD1CON1CLR = 0x00000002
#define ADC_START() AD1CON1SET = 0x00008000
#define ADC_STOP() AD1CON1CLR = 0x00008000
#endif

#ifdef	__cplusplus
}
#endif

#endif	/* ADC_H */

