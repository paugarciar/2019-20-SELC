/* 
 * File:   button.h
 * Author: malagon
 *
 * Created on May 11, 2017, 4:20 PM
 */

#ifndef BUTTON_H
#define	BUTTON_H

#ifdef	__cplusplus
extern "C" {
#endif

void button_setup();
int button_pressed();

#define BUTTON_START()    IFS0bits.INT0IF=0; IEC0bits.INT0IE=1
#define BUTTON_STOP()     IEC0bits.INT0IE=0


#ifdef	__cplusplus
}
#endif

#endif	/* BUTTON_H */

