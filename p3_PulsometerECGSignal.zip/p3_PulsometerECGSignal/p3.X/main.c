/**************************************************/
// Relevant device configuration bits
#pragma config FNOSC = FRC              // Oscillator Selection Bits (Fast RC Osc with divisor (FRCDIV))
#pragma config FWDTEN = OFF             // Watchdog Timer Enable (WDT Disabled (SWDTEN Bit Controls))
#pragma config WDTPS = PS1              // Watchdog Timer Postscaler (1:1)
#pragma config FPBDIV = DIV_8           // Peripheral Clock Divisor (Pb_Clk is Sys_Clk/1)

#include <xc.h>
#include <stdio.h>

//FPBCLK -> 1 MHz
#include <sys/attribs.h>

#include "adc.h"
#include "algorithm.h"
#include "button.h"
#include "config.h"
#include "data.h"
#include "timer.h"
#include "buzzer.h"


typedef enum {
    INIT,
    NOT_SAMPLING,
    SAMPLING,
    PRINTING
} stateT;

void
print_setup () {
#ifndef __MPLAB_DEBUGGER_SIMULATOR    
    TRISCbits.TRISC9 = 0;
    RPC9R = 2;  //RPC9: U2TX

    U2MODE = 8;
    U2STA = 0;
    U2BRG = GetPeripheralClock()/(115200*4)-1;
    U2STAbits.UTXEN = 1;
    U2MODESET = 0x8000;
#endif
}

int main(void) {
    int rates[RATES_SIZE+1];
    int rate_index, result;
    int peep_changes, peep_duration;
    int working;
   
    stateT state = INIT;
    
    peep_changes = INIT_PEEPS*2;
    peep_duration = PEEP_INIT;
    
    buzzer_setup();
    print_setup();
    button_setup();
    timer_setup(1);
    adc_setup();

    printf("Inicio del sistema beat_rate\n");
    
    INTCONbits.MVEC = 1;
    GIE();

    timer_start();
    
    while (1) {
        working = 0;
        switch (state) {
            case INIT:
                if (! peep_active()) {
                    if (peep_changes--) {
                        peep_start(peep_duration);
                        buzzer_invert();
                    } else {
                        buzzer_off();
                        state = NOT_SAMPLING;
                        timer_stop();
                        printf("Pulse un boton para iniciar una medida\n");
                        BUTTON_START();
                        OSCCONbits.SLPEN = 1;
                    }
                }
                break;
                
            case NOT_SAMPLING:
                if (button_pressed()) {
                    state = SAMPLING;
                    rate_index = 0;
                    data_setup();
                    alg_setup();
                    signal_start(SIGNAL_TIMEOUT);
                    BUTTON_STOP();
                    timer_start();
                    ADC_START();
                    OSCCONbits.SLPEN = 0;  //SLEEP inactivo en sampling
                }
                break;
                
            case SAMPLING:
                if (alg_detect(rates+rate_index)) {
                    working = 1;
                    if (rates[rate_index]) {
                        DBGprintf(("QRS %d found: %d", rate_index, rates[rate_index]));
                        if (rate_index) {
                            DBGprintf((" -> %d", 60*PERIOD/(rates[rate_index]-rates[rate_index-1])));
                        }
                        DBGprintf(("\n"));
                        rate_index++;
                        if (rate_index > RATES_SIZE) {
                            ADC_STOP();
                            state = PRINTING;
                        } else {
                            //Detected: peep. Short pulse
                            peep_start(PEEP_SAMPLING);
                            buzzer_on();
                            signal_start(SIGNAL_TIMEOUT);
                        }
                    }
                }
                if (! peep_active()) {
                    buzzer_off();
                }
                /*if (! signal_active()) {
                    peep_changes= TIMEOUT_PEEPS*2;
                    peep_duration=PEEP_TIMEOUT;
                    state=INIT;
                    printf("No se detecta ritmo cardiaco\n");
                    }*/
                    
                break;
            
            case PRINTING:
                result = 0;
                for (rate_index = 1; rate_index <= RATES_SIZE; rate_index++) {
                    result += rates[rate_index] - rates[rate_index-1];
                }
                result /= RATES_SIZE;
                printf("Ritmo cardiaco medio: %d\n", 60*PERIOD/result);
                peep_start(PEEP_END);
                peep_changes = 0;
                buzzer_on();
                state = INIT;
                break;
            default:
                break;
        }        
        
        if (! working) {
            IDLE();
        }
    }
    
    return (EXIT_SUCCESS);
}

