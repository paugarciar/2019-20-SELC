#include "buzzer.h"

void
buzzer_setup() {
    TRISACLR = LED_MASK;
    PORTACLR = LED_MASK;
    
    //BUZZER CONFIG
    ANSELBCLR = BUZZER_MASK;
    LATBCLR   = BUZZER_MASK;
    TRISBCLR  = BUZZER_MASK;
    RPB13R    = 6;
    
    OC5CON    = 0x000E;
    OC5R      = PR3_VAL/2;
    OC5RS     = PR3_VAL/2;
}

void
buzzer_invert() {
    PORTAINV = LED_MASK;
    OC5CONINV = 0x8000;
}

void
buzzer_on() {
    PORTASET = LED_MASK;
    OC5CONSET = 0x8000;
}

void
buzzer_off() {
    PORTACLR = LED_MASK;
    OC5CONCLR = 0x8000;
}
