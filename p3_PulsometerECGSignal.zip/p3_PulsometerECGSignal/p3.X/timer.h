/* 
 * File:   timer.h
 * Author: malagon
 *
 * Created on May 11, 2017, 3:37 PM
 */

#ifndef TIMER_H
#define	TIMER_H

#ifdef	__cplusplus
extern "C" {
#endif

void timer_setup (int interrupt);
void timer_start ();
void timer_stop ();

#define TIMER_RUNNING() \
    T3CONbits.ON

void peep_start(int ms);
int peep_active();
void signal_start(int ms);
int signal_active();
void reset_tick();


#ifdef	__cplusplus
}
#endif

#endif	/* TIMER_H */

