/* 
 * File:   algorithm.h
 * Author: malagon
 *
 * Created on May 12, 2017, 4:12 AM
 */

#ifndef ALGORITHM_H
#define	ALGORITHM_H

#ifdef	__cplusplus
extern "C" {
#endif

/*
 * alg_setup()
 * Reset the internal variables of the QRS algorithm
 * 
 */
void alg_setup();

/*
 * alg_detect(int* result)
 * Checks the data buffer for enough data to process the algorithm.
 * 
 * arguments: int* result: memory address to store the iteration (sample) when the QRS was found. Initially 0
 * 
 * return value: 1 if there are enough data stored to run the algorithm
 *               0 if there are not enough data yet to run the algorithm (filling filter variables)
 * 
 * 
 */
int alg_detect(int* result);

#ifdef	__cplusplus
}
#endif

#endif	/* ALGORITHM_H */

