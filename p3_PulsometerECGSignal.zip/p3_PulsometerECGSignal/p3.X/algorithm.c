#include "data.h"

#define M 5
#define N 30
#define WIN_SIZE 200

int iter;
int hp_sum;
int lp_sum;

int hp_buff[M+1] = {0};
int hp_wr_index;

int win_index;
int win_max;

int triggered;
int trig_time;
int threshold;


void 
alg_setup() {
    iter = 0;
    hp_sum = 0;
    lp_sum = 0;
    hp_wr_index = 0;
    threshold = 0;
    
    triggered = 0;
    trig_time = 0;
    
    win_index = 0;
    win_max = -1000000;
}

int
alg_detect(int* result) {
    int next_eval_pt;

    if(iter < M){
        if (data_available() <= iter) {
            return 0;
        }
        // first fill buffer with enough points for HP filter
        hp_sum += data_read(iter);
        hp_buff[hp_wr_index] = 0;
    } else {
        if (data_available() <= M) {
            return 0;
        }
        int y2 = data_read(M/2);
        hp_sum += data_read(M);
        hp_sum -= data_pop();
        int y1 = hp_sum / M;

        hp_buff[hp_wr_index] = y2 - y1;
    }

    lp_sum += hp_buff[hp_wr_index] * hp_buff[hp_wr_index];

    // done writing to HP buffer, increment position
    hp_wr_index++;
    hp_wr_index %= (N+1);

    if (iter < N) {
        // first fill buffer with enough points for LP filter
        next_eval_pt = 0;
    } else {
        // shift out oldest data point
        lp_sum -= hp_buff[hp_wr_index] * hp_buff[hp_wr_index];
        next_eval_pt = lp_sum;
    }

    /* Adapative thresholding beat detection */
    // set initial threshold                                
    if(iter < WIN_SIZE) {
        if (next_eval_pt > threshold) {
            threshold = next_eval_pt;
        }
    }

    iter++;

    // check if detection hold off period has passed
    if (triggered) {
        trig_time++;

        if (trig_time >= 100) {
            triggered = 0;
            trig_time = 0;
        }
    }

    // find if we have a new max
    if (next_eval_pt > win_max) {
        win_max = next_eval_pt;
    }

    // find if we are above adaptive threshold
    if (next_eval_pt > threshold && !triggered) {
        triggered = 1;
        *result = iter;
        return 1;
    }
    // else we'll finish the function before returning FALSE,
    // to potentially change threshold

    // adjust adaptive threshold using max of signal found 
    // in previous window            
    if (win_index++ >= WIN_SIZE) {
        // compute new threshold
        threshold = (9 * win_max + 972 * threshold)/1024;

        // reset current window index
        win_index = 0;
        win_max = -10000000;
    }

    // return false if we didn't detect a new QRS
    *result = 0;
    return 1;
}
