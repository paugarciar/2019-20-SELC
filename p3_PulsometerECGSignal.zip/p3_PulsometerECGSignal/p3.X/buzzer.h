#ifndef BUZZER_H
#define BUZZER_H

#include "config.h"

void buzzer_setup();
void buzzer_invert();
void buzzer_on();
void buzzer_off();

#endif /* BUZZER_H */
