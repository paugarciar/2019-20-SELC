#include <xc.h>
#include <sys/attribs.h>

#include "adc.h"
#include "config.h"
#include "data.h"
#include "timer.h"

volatile int signal_timeout = 0;
volatile int peep_timeout = 0;
volatile int tick;

void
peep_start(int ms) {
    peep_timeout = tick + ms * PERIOD / 1000;
}

int
peep_active() {
    return tick < peep_timeout;
}

void
signal_start(int ms) {
    signal_timeout = tick + ms * PERIOD / 1000;
}

int
signal_active() {
    return tick < signal_timeout;
}

inline void timer_start() {
    TMR3 = 0;
    T3CONSET = 0x00008000;
}

inline void timer_stop() {
    T3CONCLR = 0x00008000;
    tick = 0;
}


void
timer_setup (int interrupt) {
    tick = 0;
    peep_timeout = 0;

    T3CON = 0;
    TMR3 = 0;
    T3CONbits.TCKPS = 2;
    PR3 = PR3_VAL;
    
    IFS0bits.T3IF = 0;
    IPC3bits.T3IP = 5;
    IEC0bits.T3IE = (interrupt != 0);
}

#ifdef ADC_STORED
typedef enum {
    ADC_SIGNAL,
    ADC_SIGNAL_VARIABLE,
    ADC_NOISE,
    ADC_SIGNAL_NOISE
} adcStateT;

short adc_buf[]={ 247, 248, 247, 248, 247, 248, 248, 247, 247, 248, 247, 249, 259, 272, 283, 295, 306, 316, 327, 336, 345, 353, 360, 366, 371, 376, 379, 382, 383, 383, 383, 381, 378, 374, 369, 363, 356, 349, 340, 331, 322, 311, 300, 289, 277, 266, 253, 247, 248, 247, 248, 248, 247, 248, 247, 248, 247, 247, 248, 247, 248, 247, 247, 248, 247, 248, 247, 247, 248, 247, 249, 252, 255, 258, 260, 261, 261, 260, 259, 256, 254, 250, 248, 248, 247, 248, 247, 248, 248, 247, 248, 247, 248, 248, 247, 248, 247, 248, 248, 247, 248, 247, 248, 248, 247, 248, 247, 248, 248, 247, 248, 247, 248, 248, 247, 248, 247, 248, 247, 247, 247, 248, 247, 248, 247, 248, 248, 247, 248, 247, 248, 248, 247, 248, 247, 248, 248, 247, 248, 247, 248, 247, 248, 257, 271, 282, 293, 303, 312, 320, 326, 330, 333, 336, 337, 336, 334, 329, 324, 316, 307, 296, 284, 272, 257, 248, 247, 247, 248, 247, 248, 248, 247, 248, 247, 248, 247, 247, 249, 245, 260, 303, 350, 394, 439, 485, 530, 575, 620, 664, 711, 755, 800, 848, 848, 800, 755, 711, 664, 621, 574, 530, 485, 439, 394, 349, 303, 261, 242, 234, 220, 210, 198, 185, 175, 161, 154, 162, 174, 186, 197, 210, 221, 233, 244, 248};
short noise[] = {0, 1, 0, -1, 1, 1, -1};
#endif

void __ISR(_TIMER_3_VECTOR, IPL5AUTO) timer3_ISR (void) {
    IFS0bits.T3IF = 0;
#ifdef ADC_STORED  
    
    static adcStateT adc_mode = ADC_SIGNAL_VARIABLE;
    static int index = 0;
    static int noise_index = 0;
    short data;
    
    do {
        switch(adc_mode) {
            case ADC_SIGNAL_VARIABLE:
                index += noise[noise_index++];
                data = adc_buf[index++];
                break;
            case ADC_SIGNAL:
                data = adc_buf[index++];
                break;
            case ADC_NOISE:
                data = 40+noise[noise_index++];
                break;
            case ADC_SIGNAL_NOISE:
                data = 3*noise[noise_index++] + adc_buf[index++];
        }
        data_save(data);
        if (index >= sizeof(adc_buf)/sizeof(short)) {
            index = 0;
        }
        if (noise_index >= sizeof(noise)/sizeof(short)) {
            noise_index = 0;
        }
    } while (index & 0x03);
#endif
    
    tick++;
}
