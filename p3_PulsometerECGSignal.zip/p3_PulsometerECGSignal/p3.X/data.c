
#define BUF_SIZE 128
volatile int data_buf[BUF_SIZE];
volatile int read_index = 0;
volatile int wr_index = 0;


void
data_setup() {
    read_index = 0;
    wr_index = 0;
}

void
data_save(int sample) { 
  data_buf[wr_index++] = sample;
  if (wr_index >= BUF_SIZE) {
    wr_index -= BUF_SIZE;
  }
}

void
data_save_len(int* data, int len) {
    while (len--) {
        data_buf[wr_index++] = *data++;
        if (wr_index >= BUF_SIZE) {
            wr_index -= BUF_SIZE;
        }
    }
}

int
data_available() {
    int count = wr_index - read_index;
    if (count < 0) {
        count += BUF_SIZE;
    }
    return count;
}

int
data_read(int offset) {
    int target = (read_index+offset)%BUF_SIZE;
    return data_buf[target];
}

int
data_read_len(int* data, int offset, int len) {
    int count= 0;

    int target = (read_index+offset)%BUF_SIZE;
    while (len--) {
        *data++ = data_buf[target++];
        count++;
        if (target >= BUF_SIZE) {
            target -= BUF_SIZE;
        }
    }
    return count;
}

int
data_pop () {
    int sample;
    sample = data_buf[read_index++];
    if (read_index >= BUF_SIZE) {
        read_index -= BUF_SIZE;
    }
    return sample;
}

int
data_pop_len(int* data, int len) {
  int count= 0;
  while ((count < len) && (read_index != wr_index)) {
    *data++ = data_buf[read_index++];
    count++;
    if (read_index >= BUF_SIZE) {
      read_index -= BUF_SIZE;
    }
  }
  return count;
}

