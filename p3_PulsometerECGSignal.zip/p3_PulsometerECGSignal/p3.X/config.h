/* 
 * File:   config.h
 * Author: malagon
 *
 * Created on May 12, 2017, 11:58 AM
 */

#ifndef CONFIG_H
#define	CONFIG_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <xc.h>
    
#define IDLE() asm volatile("wait")
#define GIE()  asm volatile("ei")
#define GID()  asm volatile("di")

#ifdef __MPLAB_DEBUGGER_SIMULATOR

#define RATES_SIZE 8
#define PEEP_INIT  40
#define PEEP_SAMPLING 10
#define PEEP_END 100
#define PEEP_TIMEOUT 20 
#define SIGNAL_TIMEOUT 500
    
#define PR3_VAL 999   
#define SYS_FREQ (1000000L)
    
#else
    
#define RATES_SIZE 16
#define PEEP_INIT  250
#define PEEP_SAMPLING 100
#define PEEP_END 1000
#define PEEP_TIMEOUT 180
#define SIGNAL_TIMEOUT 1000
    
#define PR3_VAL 39999

#define SYS_FREQ (40000000L)
    
#endif
#define INIT_PEEPS 3
#define TIMEOUT_PEEPS 5 
           
#define LED_MASK 0x0400
#define BUZZER_MASK 0x2000

#define UART_MODULE_ID UART2

#define GetPeripheralClock()            (SYS_FREQ/(1 << OSCCONbits.PBDIV))
#define GetInstructionClock()           (SYS_FREQ)

#define PERIOD 250

//#define ADC_STORED
#define DEBUG

#ifdef DEBUG
#define DBGprintf(a) printf a
#else
#define DBGprintf(a)
#endif


#ifdef	__cplusplus
}
#endif

#endif	/* CONFIG_H */

