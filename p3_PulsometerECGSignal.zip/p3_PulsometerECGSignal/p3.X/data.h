/* 
 * File:   ring_buffer.h
 * Author: malagon
 *
 * Created on May 11, 2017, 4:15 PM
 */

#ifndef RING_BUFFER_H
#define	RING_BUFFER_H

#ifdef	__cplusplus
extern "C" {
#endif

void data_setup();
void data_save(int sample);
void data_save_len(int* data, int len);
int data_available();
int data_read(int offset);
int data_read_len(int* data, int offset, int len);
int data_pop ();
int data_pop_len(int* data, int len);

#ifdef	__cplusplus
}
#endif

#endif	/* RING_BUFFER_H */

